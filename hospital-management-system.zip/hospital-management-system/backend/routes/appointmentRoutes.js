import express from "express";
import Appointment from "../models/Appointment.js";

const router = express.Router();

// GET appointments with doctor + patient names
router.get("/", async (req, res) => {
  try {
    const appointments = await Appointment.find()
      .populate("doctor")
      .populate("patient");
    res.json(appointments);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// CREATE appointment
router.post("/", async (req, res) => {
  try {
    const { doctor, patient, date, time, notes } = req.body;
    const appointment = await Appointment.create({ doctor, patient, date, time, notes });
    res.status(201).json(appointment);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// DELETE appointment
router.delete("/:id", async (req, res) => {
  try {
    await Appointment.findByIdAndDelete(req.params.id);
    res.json({ message: "Appointment deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
