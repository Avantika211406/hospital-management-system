import "./styles.css";
import DoctorManagement from "./components/DoctorManagement";
import PatientManagement from "./components/PatientManagement";
import AppointmentManagement from "./components/AppointmentManagement";
import "./App.css";


function App() {
  return (
    <div>
      <h1 style={{ textAlign: "center", marginTop: "20px" }}>
        Hospital Management System
      </h1>

      <DoctorManagement />
      <PatientManagement />
      <AppointmentManagement />
    </div>
  );
}

export default App;


