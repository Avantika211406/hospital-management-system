import React, { useState, useEffect } from "react";

function DoctorForm({ doctor, onSubmit }) {
  const [name, setName] = useState("");
  const [specialization, setSpecialization] = useState("");

  useEffect(() => {
    if (doctor) {
      setName(doctor.name);
      setSpecialization(doctor.specialization);
    }
  }, [doctor]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ id: doctor ? doctor.id : null, name, specialization });
    setName("");
    setSpecialization("");
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginTop: "20px" }}>
      <input
        type="text"
        placeholder="Doctor Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Specialization"
        value={specialization}
        onChange={(e) => setSpecialization(e.target.value)}
        required
      />
      <button type="submit">{doctor ? "Update" : "Add"}</button>
    </form>
  );
}

export default DoctorForm;
