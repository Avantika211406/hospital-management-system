import React, { useEffect, useState } from "react";

const API_APPTS = "http://localhost:5000/api/appointments";
const API_DOCS = "http://localhost:5000/api/doctors";
const API_PATS = "http://localhost:5000/api/patients";

const AppointmentManagement = () => {
  const [appointments, setAppointments] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [patients, setPatients] = useState([]);
  const [doctor, setDoctor] = useState("");
  const [patient, setPatient] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [notes, setNotes] = useState("");
  const [msg, setMsg] = useState("");

  const loadAll = async () => {
    try {
      const aRes = await fetch(API_APPTS);
      const dRes = await fetch(API_DOCS);
      const pRes = await fetch(API_PATS);

      setAppointments(await aRes.json());
      setDoctors(await dRes.json());
      setPatients(await pRes.json());
    } catch (e) {
      console.error(e);
      setMsg("Error loading data");
    }
  };

  useEffect(() => {
    loadAll();
  }, []);

  const addAppointment = async () => {
    if (!doctor || !patient || !date || !time) {
      setMsg("Please fill all fields");
      return;
    }

    try {
      await fetch(API_APPTS, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ doctor, patient, date, time, notes }),
      });

      setDoctor("");
      setPatient("");
      setDate("");
      setTime("");
      setNotes("");

      setMsg("Appointment added");
      loadAll();
    } catch (e) {
      console.error(e);
      setMsg("Failed to add appointment");
    }
  };

  const remove = async (id) => {
    try {
      await fetch(`${API_APPTS}/${id}`, { method: "DELETE" });
      loadAll();
    } catch (e) {
      console.error(e);
    }
  };

  return (
  <div className="section-box">
    <h2 className="page-title">Appointment Management</h2>


      {msg && (
        <div style={{ margin: "10px auto", padding: "8px", border: "1px solid #ddd", width: "350px" }}>
          {msg}
        </div>
      )}

      <div style={{ marginBottom: "15px" }}>
        <select value={doctor} onChange={(e) => setDoctor(e.target.value)}>
          <option value="">Select Doctor</option>
          {doctors.map((d) => (
            <option key={d._id} value={d._id}>
              {d.name} ({d.specialization})
            </option>
          ))}
        </select>

        <select value={patient} onChange={(e) => setPatient(e.target.value)} style={{ marginLeft: "10px" }}>
          <option value="">Select Patient</option>
          {patients.map((p) => (
            <option key={p._id} value={p._id}>
              {p.name} ({p.disease})
            </option>
          ))}
        </select>

        <input type="date" value={date} onChange={(e) => setDate(e.target.value)} style={{ marginLeft: "10px" }} />
        <input type="time" value={time} onChange={(e) => setTime(e.target.value)} style={{ marginLeft: "10px" }} />
        <input
          type="text"
          placeholder="Notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          style={{ marginLeft: "10px" }}
        />

        <button className="btn btn-primary" onClick={addAppointment} style={{ marginLeft: "10px" }}>Add Appointment</button>


      </div>

      <table border="1" style={{ margin: "0 auto", width: "80%", borderCollapse: "collapse" }}>
        <thead>
          <tr>
            <th>Doctor</th>
            <th>Patient</th>
            <th>Date</th>
            <th>Time</th>
            <th>Notes</th>
            <th>Actions</th>
          </tr>
        </thead>

        <tbody>
          {appointments.length === 0 ? (
            <tr>
              <td colSpan="6" style={{ padding: "10px" }}>No appointments yet</td>
            </tr>
          ) : (
            appointments.map((a) => (
              <tr key={a._id}>
                <td>
  {a.doctor
    ? `${a.doctor.name} (${a.doctor.specialization})`
    : "❗ Doctor Unavailable"}
</td>

<td>
  {a.patient
    ? a.patient.name
    : "❗ Patient Unavailable"}
</td>

                <td>{new Date(a.date).toLocaleDateString("en-GB")}</td>

                <td>{a.time}</td>
                <td>{a.notes}</td>
                <td>
                 <button className="delete-btn" onClick={() => remove(a._id)}>
  Delete
</button>



                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default AppointmentManagement;
