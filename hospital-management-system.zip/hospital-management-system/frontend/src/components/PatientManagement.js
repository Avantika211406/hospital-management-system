import React, { useEffect, useState } from "react";

const API = "http://localhost:5000/api/patients";

const PatientManagement = () => {
  const [patients, setPatients] = useState([]);
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [disease, setDisease] = useState("");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const fetchPatients = async () => {
    try {
      setLoading(true);
      const res = await fetch(API);
      if (!res.ok) throw new Error(`GET /patients failed: ${res.status}`);
      const data = await res.json();
      setPatients(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
      setMsg("Failed to load patients. Check backend.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPatients();
  }, []);

  const addPatient = async () => {
    if (!name.trim() || !age || !disease.trim()) {
      setMsg("Name, Age and Disease are required");
      return;
    }
    try {
      setLoading(true);
      setMsg("");
      const res = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), age: Number(age), disease: disease.trim() }),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`POST /patients failed: ${res.status} ${text}`);
      }
      await res.json();
      setName(""); setAge(""); setDisease("");
      await fetchPatients();
      setMsg("Patient added");
    } catch (e) {
      console.error(e);
      setMsg("Failed to add patient. See console.");
    } finally {
      setLoading(false);
    }
  };

  const deletePatient = async (id) => {
    try {
      setLoading(true);
      setMsg("");
      const res = await fetch(`${API}/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error(`DELETE /patients/${id} failed: ${res.status}`);
      await fetchPatients();
      setMsg("Patient deleted");
    } catch (e) {
      console.error(e);
      setMsg("Failed to delete patient. See console.");
    } finally {
      setLoading(false);
    }
  };

  return (
  <div className="section-box">
    <h2 className="page-title">Patient Management</h2>


      {msg && (
        <div style={{ margin: "10px auto", padding: 8, border: "1px solid #ddd", width: 420, textAlign: "center" }}>
          {msg}
        </div>
      )}

      <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 12 }}>
        <input
          type="text"
          placeholder="Patient Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="number"
          placeholder="Age"
          value={age}
          onChange={(e) => setAge(e.target.value)}
        />
        <input
          type="text"
          placeholder="Disease"
          value={disease}
          onChange={(e) => setDisease(e.target.value)}
        />
       <button className="btn btn-primary" onClick={addPatient} disabled={loading}>Add Patient</button>

      </div>

      <table border="1" style={{ margin: "0 auto", borderCollapse: "collapse", width: "80%" }}>
        <thead>
          <tr>
            <th style={{ padding: 6 }}>ID</th>
            <th style={{ padding: 6 }}>Name</th>
            <th style={{ padding: 6 }}>Age</th>
            <th style={{ padding: 6 }}>Disease</th>
            <th style={{ padding: 6 }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {loading && patients.length === 0 ? (
            <tr><td colSpan="5" style={{ textAlign: "center", padding: 12 }}>Loading…</td></tr>
          ) : patients.length === 0 ? (
            <tr><td colSpan="5" style={{ textAlign: "center", padding: 12 }}>No patients yet</td></tr>
          ) : (
            patients.map((p) => (
              <tr key={p._id}>
                <td style={{ padding: 6 }}>{p._id}</td>
                <td style={{ padding: 6 }}>{p.name}</td>
                <td style={{ padding: 6 }}>{p.age}</td>
                <td style={{ padding: 6 }}>{p.disease}</td>
                <td style={{ padding: 6 }}>
                 <button className="btn btn-danger" onClick={() => deletePatient(p._id)} disabled={loading}>Delete</button>

                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default PatientManagement;
