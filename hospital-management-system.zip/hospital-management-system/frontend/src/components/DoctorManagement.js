import React, { useEffect, useState } from "react";

const API = "http://localhost:5000/api/doctors";

const DoctorManagement = () => {
  const [doctors, setDoctors] = useState([]);
  const [name, setName] = useState("");
  const [specialization, setSpecialization] = useState("");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  const fetchDoctors = async () => {
    try {
      setLoading(true);
      const res = await fetch(API);
      if (!res.ok) throw new Error(`GET /doctors failed: ${res.status}`);
      const data = await res.json();
      setDoctors(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
      setMsg("Failed to load doctors. Check backend.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDoctors();
  }, []);

  const addDoctor = async () => {
    if (!name.trim() || !specialization.trim()) {
      setMsg("Name and Specialization are required");
      return;
    }
    try {
      setLoading(true);
      setMsg("");
      const res = await fetch(API, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), specialization: specialization.trim() }),
      });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(`POST /doctors failed: ${res.status} ${text}`);
      }
      await res.json(); // created doc (not used directly)
      setName("");
      setSpecialization("");
      await fetchDoctors(); // refresh list so table updates
      setMsg("Doctor added");
    } catch (e) {
      console.error(e);
      setMsg("Failed to add doctor. See console.");
    } finally {
      setLoading(false);
    }
  };

  const deleteDoctor = async (id) => {
    try {
      setLoading(true);
      setMsg("");
      const res = await fetch(`${API}/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error(`DELETE /doctors/${id} failed: ${res.status}`);
      await fetchDoctors();
      setMsg("Doctor deleted");
    } catch (e) {
      console.error(e);
      setMsg("Failed to delete doctor. See console.");
    } finally {
      setLoading(false);
    }
  };

  return (
  <div className="section-box">
    <h2 className="page-title">Doctor Management</h2>


      {msg && (
        <div style={{ margin: "10px auto", padding: 8, border: "1px solid #ddd", width: 420, textAlign: "center" }}>
          {msg}
        </div>
      )}

      <div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 12 }}>
        <input
          type="text"
          placeholder="Doctor Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="text"
          placeholder="Specialization"
          value={specialization}
          onChange={(e) => setSpecialization(e.target.value)}
        />
        <button className="btn btn-primary" onClick={addDoctor} disabled={loading}>Add Doctor</button>


      </div>

      <table
        border="1"
        style={{ margin: "0 auto", borderCollapse: "collapse", width: "80%" }}
      >
        <thead>
          <tr>
            <th style={{ padding: 6 }}>ID</th>
            <th style={{ padding: 6 }}>Name</th>
            <th style={{ padding: 6 }}>Specialization</th>
            <th style={{ padding: 6 }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {loading && doctors.length === 0 ? (
            <tr><td colSpan="4" style={{ textAlign: "center", padding: 12 }}>Loading…</td></tr>
          ) : doctors.length === 0 ? (
            <tr><td colSpan="4" style={{ textAlign: "center", padding: 12 }}>No doctors yet</td></tr>
          ) : (
            doctors.map((doc) => (
              <tr key={doc._id}>
                <td style={{ padding: 6 }}>{doc._id}</td>
                <td style={{ padding: 6 }}>{doc.name}</td>
                <td style={{ padding: 6 }}>{doc.specialization}</td>
                <td style={{ padding: 6 }}>
                 <button className="btn btn-danger" onClick={() => deleteDoctor(doc._id)} disabled={loading}>Delete</button>


                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default DoctorManagement;
