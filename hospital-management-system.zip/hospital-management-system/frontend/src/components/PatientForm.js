import React, { useState, useEffect } from "react";

function PatientForm({ patient, onSubmit }) {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [disease, setDisease] = useState("");

  useEffect(() => {
    if (patient) {
      setName(patient.name);
      setAge(patient.age);
      setDisease(patient.disease);
    }
  }, [patient]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ id: patient ? patient.id : null, name, age, disease });
    setName("");
    setAge("");
    setDisease("");
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginTop: "20px" }}>
      <input
        type="text"
        placeholder="Patient Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      <input
        type="number"
        placeholder="Age"
        value={age}
        onChange={(e) => setAge(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Disease"
        value={disease}
        onChange={(e) => setDisease(e.target.value)}
        required
      />
      <button type="submit">{patient ? "Update" : "Add"}</button>
    </form>
  );
}

export default PatientForm;
